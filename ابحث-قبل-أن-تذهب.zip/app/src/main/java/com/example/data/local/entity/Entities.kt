package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stores")
data class StoreEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val ownerName: String = "",
    val category: String,
    val phone: String,
    val whatsapp: String,
    val city: String,
    val district: String,
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val rating: Float = 4.8f,
    val verified: Boolean = true,
    val imageUrl: String = ""
)

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val storeId: Long,
    val name: String,
    val nameEn: String = "",
    val category: String,
    val description: String = "",
    val price: Double,
    val currency: String = "YER", // YER, SAR, USD
    val stockStatus: String = "متوفر", // "متوفر", "كمية محدودة", "غير متوفر"
    val stockQuantity: Int = 10,
    val imageUrl: String = "",
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nameAr: String,
    val nameEn: String,
    val iconName: String,
    val itemCount: Int = 0
)

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "search_history")
data class SearchHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val query: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "exchange_rates")
data class ExchangeRateEntity(
    @PrimaryKey val currencyCode: String, // YER, SAR, USD
    val currencyName: String,
    val rateToYER: Double
)

@Entity(tableName = "excel_imports")
data class ExcelImportReportEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val storeName: String,
    val fileName: String,
    val timestamp: Long = System.currentTimeMillis(),
    val newItems: Int,
    val updatedItems: Int,
    val duplicates: Int,
    val errors: Int
)
