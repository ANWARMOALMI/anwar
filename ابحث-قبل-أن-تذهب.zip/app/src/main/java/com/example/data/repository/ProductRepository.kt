package com.example.data.repository

import com.example.data.local.dao.CategoryDao
import com.example.data.local.dao.ExchangeRateDao
import com.example.data.local.dao.FavoriteDao
import com.example.data.local.dao.ProductDao
import com.example.data.local.dao.SearchHistoryDao
import com.example.data.local.dao.StoreDao
import com.example.data.local.entity.CategoryEntity
import com.example.data.local.entity.ExchangeRateEntity
import com.example.data.local.entity.FavoriteEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.SearchHistoryEntity
import com.example.data.local.entity.StoreEntity
import com.example.data.model.ProductWithStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

class ProductRepository(
    private val productDao: ProductDao,
    private val storeDao: StoreDao,
    private val categoryDao: CategoryDao,
    private val favoriteDao: FavoriteDao,
    private val searchHistoryDao: SearchHistoryDao,
    private val exchangeRateDao: ExchangeRateDao
) {

    fun getSearchProductsWithStores(
        query: String,
        selectedCategory: String? = null,
        selectedCity: String? = null,
        onlyAvailable: Boolean = false
    ): Flow<List<ProductWithStore>> {
        val productsFlow = if (query.isBlank()) {
            productDao.getAllProducts()
        } else {
            productDao.searchProducts(query.trim())
        }
        val storesFlow = storeDao.getAllStores()
        val favoritesFlow = favoriteDao.getAllFavorites()

        return combine(productsFlow, storesFlow, favoritesFlow) { products, stores, favorites ->
            val storeMap = stores.associateBy { it.id }
            val favProductIds = favorites.map { it.productId }.toSet()

            products
                .filter { product ->
                    val store = storeMap[product.storeId] ?: return@filter false

                    val matchesCategory = selectedCategory.isNullOrBlank() || selectedCategory == "الكل" || product.category.contains(selectedCategory, ignoreCase = true)
                    val matchesCity = selectedCity.isNullOrBlank() || selectedCity == "كل المدن" || store.city.contains(selectedCity, ignoreCase = true)
                    val matchesAvailability = !onlyAvailable || product.stockStatus == "متوفر"

                    matchesCategory && matchesCity && matchesAvailability
                }
                .map { product ->
                    val store = storeMap[product.storeId] ?: StoreEntity(
                        name = "متجر غير معروف",
                        category = "عام",
                        phone = "",
                        whatsapp = "",
                        city = "صنعاء",
                        district = "",
                        address = "",
                        latitude = 15.35,
                        longitude = 44.20
                    )
                    
                    // Simple mock distance calculation based on ID offset
                    val calculatedDistance = 0.4 + ((product.id * 7) % 35) / 10.0

                    ProductWithStore(
                        product = product,
                        store = store,
                        isFavorite = favProductIds.contains(product.id),
                        distanceKm = calculatedDistance
                    )
                }
        }
    }

    suspend fun getProductDetails(productId: Long): ProductWithStore? {
        val product = productDao.getProductById(productId) ?: return null
        val store = storeDao.getStoreById(product.storeId) ?: StoreEntity(
            name = "متجر عام",
            category = "عام",
            phone = "",
            whatsapp = "",
            city = "صنعاء",
            district = "",
            address = "",
            latitude = 15.35,
            longitude = 44.20
        )
        return ProductWithStore(
            product = product,
            store = store,
            distanceKm = 1.4
        )
    }

    fun getAllCategories(): Flow<List<CategoryEntity>> = categoryDao.getAllCategories()

    fun getRecentSearches(): Flow<List<SearchHistoryEntity>> = searchHistoryDao.getRecentSearches()

    suspend fun saveSearchQuery(query: String) {
        if (query.isNotBlank()) {
            searchHistoryDao.insertSearch(SearchHistoryEntity(query = query.trim()))
        }
    }

    suspend fun clearSearchHistory() {
        searchHistoryDao.clearHistory()
    }

    fun isFavorite(productId: Long): Flow<Boolean> = favoriteDao.isFavorite(productId)

    suspend fun toggleFavorite(productId: Long, isFav: Boolean) {
        if (isFav) {
            favoriteDao.removeFavorite(productId)
        } else {
            favoriteDao.addFavorite(FavoriteEntity(productId = productId))
        }
    }

    fun getFavoriteProducts(): Flow<List<ProductWithStore>> {
        val productsFlow = productDao.getAllProducts()
        val storesFlow = storeDao.getAllStores()
        val favoritesFlow = favoriteDao.getAllFavorites()

        return combine(productsFlow, storesFlow, favoritesFlow) { products, stores, favorites ->
            val storeMap = stores.associateBy { it.id }
            val favProductIds = favorites.map { it.productId }.toSet()

            products
                .filter { favProductIds.contains(it.id) }
                .map { product ->
                    val store = storeMap[product.storeId] ?: StoreEntity(
                        name = "متجر عام",
                        category = "عام",
                        phone = "",
                        whatsapp = "",
                        city = "صنعاء",
                        district = "",
                        address = "",
                        latitude = 15.35,
                        longitude = 44.20
                    )
                    ProductWithStore(
                        product = product,
                        store = store,
                        isFavorite = true,
                        distanceKm = 1.1
                    )
                }
        }
    }

    fun getExchangeRates(): Flow<List<ExchangeRateEntity>> = exchangeRateDao.getExchangeRates()

    suspend fun updateExchangeRate(code: String, name: String, rateToYER: Double) {
        exchangeRateDao.updateRate(ExchangeRateEntity(currencyCode = code, currencyName = name, rateToYER = rateToYER))
    }

    suspend fun addProduct(product: ProductEntity): Long = productDao.insertProduct(product)

    suspend fun updateProduct(product: ProductEntity) = productDao.updateProduct(product)

    suspend fun deleteProduct(id: Long) = productDao.deleteProductById(id)

    suspend fun addStore(store: StoreEntity): Long = storeDao.insertStore(store)

    fun getAllStores(): Flow<List<StoreEntity>> = storeDao.getAllStores()
}
