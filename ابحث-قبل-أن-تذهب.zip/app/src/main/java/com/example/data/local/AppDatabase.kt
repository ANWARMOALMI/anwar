package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.CategoryDao
import com.example.data.local.dao.ExcelImportDao
import com.example.data.local.dao.ExchangeRateDao
import com.example.data.local.dao.FavoriteDao
import com.example.data.local.dao.ProductDao
import com.example.data.local.dao.SearchHistoryDao
import com.example.data.local.dao.StoreDao
import com.example.data.local.entity.CategoryEntity
import com.example.data.local.entity.ExcelImportReportEntity
import com.example.data.local.entity.ExchangeRateEntity
import com.example.data.local.entity.FavoriteEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.SearchHistoryEntity
import com.example.data.local.entity.StoreEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        StoreEntity::class,
        ProductEntity::class,
        CategoryEntity::class,
        FavoriteEntity::class,
        SearchHistoryEntity::class,
        ExchangeRateEntity::class,
        ExcelImportReportEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun storeDao(): StoreDao
    abstract fun productDao(): ProductDao
    abstract fun categoryDao(): CategoryDao
    abstract fun favoriteDao(): FavoriteDao
    abstract fun searchHistoryDao(): SearchHistoryDao
    abstract fun exchangeRateDao(): ExchangeRateDao
    abstract fun excelImportDao(): ExcelImportDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "find_before_go_db"
                )
                .addCallback(DatabaseCallback(scope))
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {

        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database)
                }
            }
        }

        suspend fun populateInitialData(db: AppDatabase) {
            val storeDao = db.storeDao()
            val productDao = db.productDao()
            val categoryDao = db.categoryDao()
            val exchangeRateDao = db.exchangeRateDao()

            // 1. Initial Exchange Rates
            exchangeRateDao.insertExchangeRates(
                listOf(
                    ExchangeRateEntity(currencyCode = "YER", currencyName = "ريال يمني", rateToYER = 1.0),
                    ExchangeRateEntity(currencyCode = "SAR", currencyName = "ريال سعودي", rateToYER = 142.5),
                    ExchangeRateEntity(currencyCode = "USD", currencyName = "دولار أمريكي", rateToYER = 535.0)
                )
            )

            // 2. Categories
            val categories = listOf(
                CategoryEntity(nameAr = "الأدوية والمستلزمات", nameEn = "Pharmacy & Medical", iconName = "medical_services", itemCount = 120),
                CategoryEntity(nameAr = "قطع غيار السيارات", nameEn = "Auto Spare Parts", iconName = "directions_car", itemCount = 85),
                CategoryEntity(nameAr = "الإلكترونيات والهواتف", nameEn = "Electronics & Mobile", iconName = "devices", itemCount = 95),
                CategoryEntity(nameAr = "السوبرماركت والغذائيات", nameEn = "Supermarket & Food", iconName = "shopping_basket", itemCount = 210),
                CategoryEntity(nameAr = "مواد البناء والسباكة", nameEn = "Construction & Plumbing", iconName = "construction", itemCount = 64),
                CategoryEntity(nameAr = "الأثاث والمكتبات", nameEn = "Furniture & Stationery", iconName = "menu_book", itemCount = 42),
                CategoryEntity(nameAr = "الملابس والأحذية", nameEn = "Fashion & Shoes", iconName = "checkroom", itemCount = 78),
                CategoryEntity(nameAr = "العطور والتجميل", nameEn = "Perfumes & Cosmetics", iconName = "clean_hands", itemCount = 53)
            )
            categoryDao.insertCategories(categories)

            // 3. Stores (Yemen Sample Stores)
            val stores = listOf(
                StoreEntity(
                    id = 1,
                    name = "صيدلية الشفاء النموذجية",
                    ownerName = "د. علي الحاشدي",
                    category = "الأدوية والمستلزمات",
                    phone = "967771234567",
                    whatsapp = "967771234567",
                    city = "صنعاء",
                    district = "التحرير",
                    address = "شارع التحرير - أمانة العاصمة - بجانب بنك اليمن والدولار",
                    latitude = 15.3522,
                    longitude = 44.2075,
                    rating = 4.9f,
                    verified = true,
                    imageUrl = ""
                ),
                StoreEntity(
                    id = 2,
                    name = "مركز اليمني لقطع غيار تويوتا وهوندا",
                    ownerName = "الشيخ أحمد باوزير",
                    category = "قطع غيار السيارات",
                    phone = "967733445566",
                    whatsapp = "967733445566",
                    city = "عدن",
                    district = "المنصورة",
                    address = "شارع التسعين - جولة الكراع - مقابل معرض السيارات",
                    latitude = 12.8311,
                    longitude = 44.9811,
                    rating = 4.7f,
                    verified = true,
                    imageUrl = ""
                ),
                StoreEntity(
                    id = 3,
                    name = "معرض القمة للهواتف والكمبيوتر",
                    ownerName = "مهندس محمد السقاف",
                    category = "الإلكترونيات والهواتف",
                    phone = "967711223344",
                    whatsapp = "967711223344",
                    city = "صنعاء",
                    district = "حدّة",
                    address = "شارع حدة - تقاطع صخر - العمارة البيضاء",
                    latitude = 15.3210,
                    longitude = 44.1890,
                    rating = 4.9f,
                    verified = true,
                    imageUrl = ""
                ),
                StoreEntity(
                    id = 4,
                    name = "سوبرماركت البركة والدكان الحديث",
                    ownerName = "أبو بكر العولقي",
                    category = "السوبرماركت والغذائيات",
                    phone = "967770001122",
                    whatsapp = "967770001122",
                    city = "تعز",
                    district = "شارع جمال",
                    address = "وسط شارع جمال - بالقرب من مستشفى الثورة",
                    latitude = 13.5789,
                    longitude = 44.0123,
                    rating = 4.6f,
                    verified = true,
                    imageUrl = ""
                ),
                StoreEntity(
                    id = 5,
                    name = "مؤسسة سبأ لمواد البناء والسباكة",
                    ownerName = "م. خالد الريمي",
                    category = "مواد البناء والسباكة",
                    phone = "967778899001",
                    whatsapp = "967778899001",
                    city = "إب",
                    district = "الدليل",
                    address = "الدائري الغربي - بجوار مجمع السعيد",
                    latitude = 13.9667,
                    longitude = 44.1833,
                    rating = 4.8f,
                    verified = true,
                    imageUrl = ""
                )
            )
            storeDao.insertStores(stores)

            // 4. Products
            val products = listOf(
                ProductEntity(
                    storeId = 1,
                    name = "باراسيتامول 500 ملجم (Paracetamol 500mg)",
                    nameEn = "Paracetamol 500mg",
                    category = "الأدوية والمستلزمات",
                    description = "مسكن للآلام وخافض للحرارة - شريط 10 أقراص. متوفر بضمان الجودة والتخزين المبرد.",
                    price = 1200.0,
                    currency = "YER",
                    stockStatus = "متوفر",
                    stockQuantity = 45,
                    lastUpdated = System.currentTimeMillis() - 3600000
                ),
                ProductEntity(
                    storeId = 1,
                    name = "أموكسيسيلين 500 ملجم مضاد حيوي (Amoxicillin)",
                    nameEn = "Amoxicillin 500mg Capsules",
                    category = "الأدوية والمستلزمات",
                    description = "كبسولات مضاد حيوي واسع المجال - كرتون 20 كبسولة. يحتاج وصفة طبية.",
                    price = 3500.0,
                    currency = "YER",
                    stockStatus = "متوفر",
                    stockQuantity = 20,
                    lastUpdated = System.currentTimeMillis() - 7200000
                ),
                ProductEntity(
                    storeId = 1,
                    name = "جهاز قياس الضغط الإلكتروني Omron M3",
                    nameEn = "Omron M3 Blood Pressure Monitor",
                    category = "الأدوية والمستلزمات",
                    description = "جهاز قياس ضغط الدم الرقمي الدقيق من أومرون اليابانية مع شاشة كبيرة وجراب لحفظ الجهاز.",
                    price = 32.0,
                    currency = "USD",
                    stockStatus = "كمية محدودة",
                    stockQuantity = 3,
                    lastUpdated = System.currentTimeMillis() - 14400000
                ),
                ProductEntity(
                    storeId = 2,
                    name = "فلتر زيت تويوتا أصلي (Toyota Oil Filter Original)",
                    nameEn = "Toyota Genuine Oil Filter",
                    category = "قطع غيار السيارات",
                    description = "فلتر زيت أصلي ياباني معتمد لموديلات كامري، كورولا، هايلوكس، ولاندكروزر.",
                    price = 12.0,
                    currency = "SAR",
                    stockStatus = "متوفر",
                    stockQuantity = 60,
                    lastUpdated = System.currentTimeMillis() - 1800000
                ),
                ProductEntity(
                    storeId = 2,
                    name = "زيت موتور تويوتا الأصلي 20W-50 (4 لتر)",
                    nameEn = "Toyota Motor Oil 20W50 4L",
                    category = "قطع غيار السيارات",
                    description = "زيت محرك معدني فاخر لحماية الأجزاء الداخلية وتحسين أداء Engine في درجات الحرارة العالية.",
                    price = 85.0,
                    currency = "SAR",
                    stockStatus = "متوفر",
                    stockQuantity = 30,
                    lastUpdated = System.currentTimeMillis() - 5400000
                ),
                ProductEntity(
                    storeId = 2,
                    name = "بطارية سيارة هانكوك كوريا 60 أمبير (Hankook Battery 60Ah)",
                    nameEn = "Hankook Auto Battery 60Ah",
                    category = "قطع غيار السيارات",
                    description = "بطارية جافة كورية عالية الاعتمادية مع ضمان لمستويات التشغيل الشاقة.",
                    price = 22000.0,
                    currency = "YER",
                    stockStatus = "متوفر",
                    stockQuantity = 12,
                    lastUpdated = System.currentTimeMillis() - 86400000
                ),
                ProductEntity(
                    storeId = 3,
                    name = "هاتف سامسونج جالاكسي S24 ألترا (Samsung S24 Ultra 256GB)",
                    nameEn = "Samsung Galaxy S24 Ultra",
                    category = "الإلكترونيات والهواتف",
                    description = "سعة 256 جيجابايت - رام 12 جيجابايت - كاميرا 200 ميجابكسل مع قلم S-Pen وضمان لمدة سنة.",
                    price = 890.0,
                    currency = "USD",
                    stockStatus = "متوفر",
                    stockQuantity = 8,
                    lastUpdated = System.currentTimeMillis() - 1200000
                ),
                ProductEntity(
                    storeId = 3,
                    name = "آيفون 15 بروماكس (iPhone 15 Pro Max 256GB)",
                    nameEn = "iPhone 15 Pro Max",
                    category = "الإلكترونيات والهواتف",
                    description = "لون تيتانيوم طبيعي - شريحتين Nano + eSIM - جديد كرتون مغلق وضمان دولي.",
                    price = 1050.0,
                    currency = "USD",
                    stockStatus = "كمية محدودة",
                    stockQuantity = 2,
                    lastUpdated = System.currentTimeMillis() - 3600000
                ),
                ProductEntity(
                    storeId = 4,
                    name = "أرز شاهين هندي بسمتي أصلي (10 كيلو)",
                    nameEn = "Shaheen Basmati Rice 10kg",
                    category = "السوبرماركت والغذائيات",
                    description = "أرز عنبر درهم درجة أولى حبة طويلة وطعم أصيل ممتاز للولائم والوجبات العائلية.",
                    price = 18500.0,
                    currency = "YER",
                    stockStatus = "متوفر",
                    stockQuantity = 100,
                    lastUpdated = System.currentTimeMillis() - 2800000
                ),
                ProductEntity(
                    storeId = 4,
                    name = "زيت عافية دوار الشمس (5 لتر)",
                    nameEn = "Afia Sunflower Oil 5L",
                    category = "السوبرماركت والغذائيات",
                    description = "زيت طهي نقي صحي خالي من الكوليسترول للطهي والقلي اليومي.",
                    price = 13200.0,
                    currency = "YER",
                    stockStatus = "متوفر",
                    stockQuantity = 40,
                    lastUpdated = System.currentTimeMillis() - 4800000
                ),
                ProductEntity(
                    storeId = 5,
                    name = "مضخة مياه يابانية إيطالية 1 حصان (Pedrollo Water Pump)",
                    nameEn = "Pedrollo 1HP Water Pump",
                    category = "مواد البناء والسباكة",
                    description = "مضخة رفع مياه قوية وهادئة الصوت مع أداء شاق وتوفير للكهرباء.",
                    price = 110.0,
                    currency = "USD",
                    stockStatus = "متوفر",
                    stockQuantity = 15,
                    lastUpdated = System.currentTimeMillis() - 9600000
                )
            )
            productDao.insertProducts(products)
        }
    }
}
