package com.example.data.model

import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.StoreEntity

data class ProductWithStore(
    val product: ProductEntity,
    val store: StoreEntity,
    val isFavorite: Boolean = false,
    val distanceKm: Double = 1.2
)
