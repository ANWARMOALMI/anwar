package com.example.utils

import com.example.data.local.dao.ExcelImportDao
import com.example.data.local.dao.ProductDao
import com.example.data.local.dao.StoreDao
import com.example.data.local.entity.ExcelImportReportEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.StoreEntity
import kotlinx.coroutines.flow.first

data class ExcelRow(
    val productName: String,
    val category: String,
    val storeName: String,
    val price: Double,
    val currency: String,
    val quantity: Int,
    val city: String,
    val address: String,
    val phone: String,
    val lat: Double,
    val lng: Double,
    val description: String
)

class ExcelImportEngine(
    private val productDao: ProductDao,
    private val storeDao: StoreDao,
    private val excelImportDao: ExcelImportDao
) {

    suspend fun importCsvContent(
        fileName: String,
        csvText: String,
        targetStoreName: String = "استيراد ملف"
    ): ExcelImportReportEntity {
        var newCount = 0
        var updatedCount = 0
        var duplicateCount = 0
        var errorCount = 0

        val lines = csvText.lines().filter { it.isNotBlank() }
        if (lines.size <= 1) {
            val report = ExcelImportReportEntity(
                storeName = targetStoreName,
                fileName = fileName,
                newItems = 0,
                updatedItems = 0,
                duplicates = 0,
                errors = 1
            )
            excelImportDao.insertReport(report)
            return report
        }

        // Header line skipped
        val existingProducts = productDao.getAllProducts().first().associateBy { "${it.name.trim().lowercase()}_${it.storeId}" }
        val existingStores = storeDao.getAllStores().first().associateBy { it.name.trim().lowercase() }

        val dataLines = lines.drop(1)
        for (line in dataLines) {
            try {
                val parts = line.split(",").map { it.trim().removeSurrounding("\"") }
                if (parts.size < 4) {
                    errorCount++
                    continue
                }

                val name = parts.getOrNull(0) ?: "منتج مستورد"
                val category = parts.getOrNull(1) ?: "عام"
                val storeName = if (parts.size > 2 && parts[2].isNotBlank()) parts[2] else targetStoreName
                val price = parts.getOrNull(3)?.toDoubleOrNull() ?: 1000.0
                val currency = parts.getOrNull(4)?.ifBlank { "YER" } ?: "YER"
                val quantity = parts.getOrNull(5)?.toIntOrNull() ?: 10
                val city = parts.getOrNull(6) ?: "صنعاء"
                val address = parts.getOrNull(7) ?: "وسط المدينة"
                val phone = parts.getOrNull(8) ?: "967770000000"
                val desc = parts.getOrNull(11) ?: "منتج مستورد عبر ملف Excel/CSV"

                // Find or create store
                val storeKey = storeName.lowercase()
                val storeId = if (existingStores.containsKey(storeKey)) {
                    existingStores[storeKey]!!.id
                } else {
                    val newStore = StoreEntity(
                        name = storeName,
                        category = category,
                        phone = phone,
                        whatsapp = phone,
                        city = city,
                        district = "المركز",
                        address = address,
                        latitude = 15.3522,
                        longitude = 44.2075
                    )
                    storeDao.insertStore(newStore)
                }

                val productKey = "${name.lowercase()}_$storeId"
                val stockStatus = if (quantity > 5) "متوفر" else if (quantity > 0) "كمية محدودة" else "غير متوفر"

                if (existingProducts.containsKey(productKey)) {
                    val existing = existingProducts[productKey]!!
                    if (existing.price == price && existing.stockQuantity == quantity) {
                        duplicateCount++
                    } else {
                        val updated = existing.copy(
                            price = price,
                            currency = currency,
                            stockQuantity = quantity,
                            stockStatus = stockStatus,
                            lastUpdated = System.currentTimeMillis()
                        )
                        productDao.updateProduct(updated)
                        updatedCount++
                    }
                } else {
                    val newProduct = ProductEntity(
                        storeId = storeId,
                        name = name,
                        category = category,
                        description = desc,
                        price = price,
                        currency = currency,
                        stockStatus = stockStatus,
                        stockQuantity = quantity,
                        lastUpdated = System.currentTimeMillis()
                    )
                    productDao.insertProduct(newProduct)
                    newCount++
                }
            } catch (e: Exception) {
                errorCount++
            }
        }

        val report = ExcelImportReportEntity(
            storeName = targetStoreName,
            fileName = fileName,
            newItems = newCount,
            updatedItems = updatedCount,
            duplicates = duplicateCount,
            errors = errorCount
        )
        val reportId = excelImportDao.insertReport(report)
        return report.copy(id = reportId)
    }

    suspend fun generateSampleProductsBatch(storeName: String): ExcelImportReportEntity {
        val sampleCsv = """
            اسم المنتج,التصنيف,اسم المحل,السعر,العملة,الكمية,المدينة,العنوان,الهاتف,خط العرض,خط الطول,الوصف
            "زيت موتور كاسترول 10W-40","قطع غيار السيارات","$storeName",18.0,"SAR",25,"صنعاء","شارع خولان","967771112233",15.35,44.20,"زيت تخليقي عالي الكفاءة لمحركات البنزين"
            "مجموعة فلاتر هواء وزيت تويوتا","قطع غيار السيارات","$storeName",45000.0,"YER",15,"صنعاء","شارع خولان","967771112233",15.35,44.20,"طقم فلاتر يابانية أصلية للسيارات اليبانية"
            "بطارية شمسية جل 200 أمبير","الإلكترونيات والهواتف","$storeName",185.0,"USD",8,"صنعاء","شارع صخر","967771112233",15.35,44.20,"بطارية طاقة شمسية دورة عميقة شحن سريع"
            "شاحن انفرتر ذكي 3000 واط","الإلكترونيات والهواتف","$storeName",140.0,"USD",5,"صنعاء","شارع صخر","967771112233",15.35,44.20,"محول طاقة شمسية ذكي مع منظم شحن MPPT"
            "فيتامين C مع زنك ألماني","الأدوية والمستلزمات","$storeName",2500.0,"YER",50,"صنعاء","شارع التحرير","967771112233",15.35,44.20,"فوار فيتامين لتعزيز المناعة وقوة الجسم"
        """.trimIndent()

        return importCsvContent(
            fileName = "products_import_batch.xlsx",
            csvText = sampleCsv,
            targetStoreName = storeName
        )
    }
}
