package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.entity.CategoryEntity
import com.example.data.local.entity.ExcelImportReportEntity
import com.example.data.local.entity.ExchangeRateEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.SearchHistoryEntity
import com.example.data.local.entity.StoreEntity
import com.example.data.model.ProductWithStore
import com.example.data.repository.ProductRepository
import com.example.utils.ExcelImportEngine
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application, viewModelScope)
    val repository = ProductRepository(
        productDao = db.productDao(),
        storeDao = db.storeDao(),
        categoryDao = db.categoryDao(),
        favoriteDao = db.favoriteDao(),
        searchHistoryDao = db.searchHistoryDao(),
        exchangeRateDao = db.exchangeRateDao()
    )

    private val excelEngine = ExcelImportEngine(
        productDao = db.productDao(),
        storeDao = db.storeDao(),
        excelImportDao = db.excelImportDao()
    )

    // User Role State: "USER", "STORE_OWNER", "ADMIN"
    private val _userRole = MutableStateFlow("USER")
    val userRole: StateFlow<String> = _userRole.asStateFlow()

    // Filters & Search
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("الكل")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _selectedCity = MutableStateFlow("كل المدن")
    val selectedCity: StateFlow<String> = _selectedCity.asStateFlow()

    private val _onlyAvailable = MutableStateFlow(false)
    val onlyAvailable: StateFlow<Boolean> = _onlyAvailable.asStateFlow()

    private val _displayCurrency = MutableStateFlow("YER") // YER, SAR, USD
    val displayCurrency: StateFlow<String> = _displayCurrency.asStateFlow()

    // Status message for actions (toast/snackbar)
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    // Main Search Results
    @OptIn(ExperimentalCoroutinesApi::class)
    val searchResults: StateFlow<List<ProductWithStore>> = kotlinx.coroutines.flow.combine(
        _searchQuery,
        _selectedCategory,
        _selectedCity,
        _onlyAvailable
    ) { query, category, city, available ->
        Triple(query, category, city to available)
    }.flatMapLatest { (query, category, cityAvail) ->
        val (city, available) = cityAvail
        repository.getSearchProductsWithStores(
            query = query,
            selectedCategory = if (category == "الكل") null else category,
            selectedCity = if (city == "كل المدن") null else city,
            onlyAvailable = available
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val categories: StateFlow<List<CategoryEntity>> = repository.getAllCategories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentSearches: StateFlow<List<SearchHistoryEntity>> = repository.getRecentSearches()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteProducts: StateFlow<List<ProductWithStore>> = repository.getFavoriteProducts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val exchangeRates: StateFlow<List<ExchangeRateEntity>> = repository.getExchangeRates()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allStores: StateFlow<List<StoreEntity>> = repository.getAllStores()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val importReports: StateFlow<List<ExcelImportReportEntity>> = db.excelImportDao().getAllReports()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setUserRole(role: String) {
        _userRole.value = role
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
        if (query.isNotBlank()) {
            viewModelScope.launch {
                repository.saveSearchQuery(query)
            }
        }
    }

    fun setCategory(category: String) {
        _selectedCategory.value = category
    }

    fun setCity(city: String) {
        _selectedCity.value = city
    }

    fun setOnlyAvailable(available: Boolean) {
        _onlyAvailable.value = available
    }

    fun setDisplayCurrency(currency: String) {
        _displayCurrency.value = currency
    }

    fun toggleFavorite(productWithStore: ProductWithStore) {
        viewModelScope.launch {
            repository.toggleFavorite(productWithStore.product.id, productWithStore.isFavorite)
            val msg = if (productWithStore.isFavorite) "تمت الإزالة من المفضلة" else "تمت الإضافة للمفضلة"
            _userMessage.value = msg
        }
    }

    fun clearSearchHistory() {
        viewModelScope.launch {
            repository.clearSearchHistory()
            _userMessage.value = "تم مسح سجل البحث"
        }
    }

    fun updateExchangeRate(code: String, name: String, rate: Double) {
        viewModelScope.launch {
            repository.updateExchangeRate(code, name, rate)
            _userMessage.value = "تم تحديث سعر الصرف"
        }
    }

    fun addNewProduct(product: ProductEntity) {
        viewModelScope.launch {
            repository.addProduct(product)
            _userMessage.value = "تمت إضافة المنتج بنجاح"
        }
    }

    fun updateProduct(product: ProductEntity) {
        viewModelScope.launch {
            repository.updateProduct(product)
            _userMessage.value = "تم تحديث بيانات المنتج"
        }
    }

    fun deleteProduct(productId: Long) {
        viewModelScope.launch {
            repository.deleteProduct(productId)
            _userMessage.value = "تم حذف المنتج"
        }
    }

    fun registerStore(store: StoreEntity) {
        viewModelScope.launch {
            repository.addStore(store)
            _userMessage.value = "تم إنشاء متجرك بنجاح!"
        }
    }

    fun simulateExcelImport(storeName: String, csvText: String? = null) {
        viewModelScope.launch {
            _userMessage.value = "جاري معالجة ملف Excel..."
            val report = if (!csvText.isNullOrBlank()) {
                excelEngine.importCsvContent("products_import.csv", csvText, storeName)
            } else {
                excelEngine.generateSampleProductsBatch(storeName)
            }
            _userMessage.value = "تم الاستيراد! تمت إضافة ${report.newItems} جديد، وتحديث ${report.updatedItems}"
        }
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    // Helper formatting currency
    fun formatPrice(amount: Double, sourceCurrency: String): String {
        val currentDisplay = _displayCurrency.value
        val rates = exchangeRates.value.associateBy { it.currencyCode }

        val sourceRateToYER = rates[sourceCurrency]?.rateToYER ?: 1.0
        val amountInYER = amount * sourceRateToYER

        val targetRateToYER = rates[currentDisplay]?.rateToYER ?: 1.0
        val convertedAmount = amountInYER / targetRateToYER

        val rounded = String.format("%.0f", convertedAmount)
        val symbol = when (currentDisplay) {
            "SAR" -> "ر.س"
            "USD" -> "$"
            else -> "ر.ي"
        }
        return "$rounded $symbol"
    }
}
